package Request;

import Model.AuthToken;

/**
 * Request consists of personID
 * Auth Token required
 */
public class PersonRequest {
    /**
     * personID passed in the URL
     */
    private String personID;

    /**
     * Auth Token required
     */
    private String authToken;

    public PersonRequest(String personID, String authToken) {
        this.personID = personID;
        this.authToken = authToken;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
}
