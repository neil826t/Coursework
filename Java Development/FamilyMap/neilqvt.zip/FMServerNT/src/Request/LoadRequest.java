package Request;

import Model.User;
import Model.Person;
import Model.Event;

/**
 * Request Body: The users property in the request body contains an array of users to be created.
 * The persons and events properties contain family history information for these users.
 * The objects contained in the persons and events arrays should be added to the server’s database.
 * The objects in the users array have the same format as those passed to the /user/register API with the addition of the personID.
 * The objects in the persons array have the same format as those returned by the /person/[personID] API.
 * The objects in the events array have the same format as those returned by the /event/[eventID] API.
 */
public class LoadRequest {
    /**
     * Array of User objects
     */
    private User[] users;
    /**
     * Array of Person objects
     */
    private Person[] persons;
    /**
     * Array of Event objects
     */
    private Event[] events;

    /**
     * Constructor
     */
    public LoadRequest(User[] users, Person[] persons, Event[] events) {
        this.users = users;
        this.persons = persons;
        this.events = events;
    }

    public User[] getUsers() {
        return users;
    }

    public void setUsers(User[] users) {
        this.users = users;
    }

    public Person[] getPersons() {
        return persons;
    }

    public void setPersons(Person[] persons) {
        this.persons = persons;
    }

    public Event[] getEvents() {
        return events;
    }

    public void setEvents(Event[] events) {
        this.events = events;
    }
}
