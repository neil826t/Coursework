package Request;

/**
 * Request consisting of username and optional generations variable located in url
 */
public class FillRequest{
    /**
     * the user's username
     */
    private String username;

    /**
     * number of generations to generate
     */
    private int generations = 4;

    public FillRequest(String username, int generations) {
        this.username = username;
        this.generations = generations;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getGenerations() {
        return generations;
    }

    public void setGenerations(int generations) {
        this.generations = generations;
    }
}
