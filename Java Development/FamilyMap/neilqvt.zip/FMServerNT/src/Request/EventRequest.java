package Request;

import Model.AuthToken;

/**
 * Request consists of eventID
 * Auth Token required
 */
public class EventRequest{
    /**
     * eventID passed in the URL
     */
    private String eventID;

    /**
     * Auth Token required
     */
    private String authToken;

    public EventRequest(String eventID, String authToken) {
        this.eventID = eventID;
        this.authToken = authToken;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
}
