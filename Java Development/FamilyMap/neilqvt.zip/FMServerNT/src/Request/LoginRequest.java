package Request;

/**
 * Request Body has userName, password
 * Auth Token not required
 */
public class LoginRequest {
    /**
     * login username
     */
    private String userName;

    /**
     * login password
     */
    private String password;

    /**
     * Constructor
     */
    public LoginRequest(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
