package Main;

import java.io.IOException;

public class Main {
    public static void main(String args[]) {

        int port = Integer.parseInt(args[0]);

        FamilyMapServer FMS = new FamilyMapServer();

        try {
            FMS.startServer(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
