package Service;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.UserDao;
import Model.AuthToken;
import Model.User;
import Request.RegisterRequest;
import Result.RegisterResult;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

/**
 * Creates a new user account, generates 4 generations of ancestor data for the new user, logs the user in, and returns an auth token.
 */
public class RegisterService extends GenerateAncestry {
    /**
     * Constructor
     */
    public RegisterService() {}

    /**
     * @param r a RegisterRequest object
     * @return a RegisterResult object
     */
    public RegisterResult register(RegisterRequest r) {

        RegisterResult result = new RegisterResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            UserDao uDao = new UserDao(conn);
            if (uDao.find(r.getUserName()) != null) {
                result.setSuccess(false);
                result.setMessage("Error: Username already exists");

            } else {
                AuthTokenDao aTDao = new AuthTokenDao(conn);
                String aT = UUID.randomUUID().toString();
                String pID = UUID.randomUUID().toString();
                aTDao.insert(new AuthToken(aT, r.getUserName()));

                User newUser = new User(
                        r.getUserName(),
                        r.getPassword(),
                        r.getEmail(),
                        r.getFirstName(),
                        r.getLastName(),
                        r.getGender(),
                        pID);
                uDao.insert(newUser);

                result.setAuthToken(aT);
                result.setPersonID(pID);
                result.setUserName(r.getUserName());
                result.setSuccess(true);

                generateAncestry(newUser, 4, conn);
            }

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);

        } catch (FileNotFoundException e) {
            result.setMessage("Error: No name files for generation found");
            result.setSuccess(false);
        }

        return result;
    }
}
