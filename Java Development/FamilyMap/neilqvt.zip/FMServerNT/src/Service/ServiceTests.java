package Service;

import DAO.*;
import Model.AuthToken;
import Model.Event;
import Model.Person;
import Model.User;
import Request.*;
import Result.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;

import static org.junit.jupiter.api.Assertions.*;

public class ServiceTests {

    private UserDao uDao;
    private PersonDao pDao;
    private EventDao eDao;
    private AuthTokenDao aTDao;
    private Database db;
    private User bestUser;
    private Person bestPerson;
    private Event bestEvent;
    private AuthToken authToken;

    //clearTests
    @BeforeEach
    public void setUp() throws DataAccessException {
        db = new Database();
        Connection conn = db.getConnection();
        db.clearTables();
        uDao = new UserDao(conn);
        pDao = new PersonDao(conn);
        eDao = new EventDao(conn);
        aTDao = new AuthTokenDao(conn);
        bestUser = new User("BikeBoy", "lotsofbikes", "bigbikeyboy",
                "Neil", "Thompson", "m", "biking");
        bestPerson = new Person("GrandpaNeilDay", "BikeBoy", "Neil",
                "Day", "m", "hisdad", "hismom", "jo");
        bestEvent = new Event("birthday", "BikeBoy", "biking", 40.000,
                -86.000, "USA", "Indiana-town", "birth", 1999);
        authToken = new AuthToken("abcd1234", "BikeBoy");
    }
    public void pause() throws DataAccessException {
        db.closeConnection(true);
    }
    public void resume() throws DataAccessException {
        db = new Database();
        Connection conn = db.getConnection();
        uDao = new UserDao(conn);
        pDao = new PersonDao(conn);
        eDao = new EventDao(conn);
        aTDao = new AuthTokenDao(conn);
    }
    @AfterEach
    public void tearDown() throws DataAccessException {
        db.clearTables();
        db.closeConnection(false);
    }

    @Test
    public void clearPass() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(authToken);
        assertEquals(bestUser, uDao.find(bestUser.getUserName()));
        assertEquals(bestPerson, pDao.find(bestPerson.getPersonID()));
        assertEquals(bestEvent, eDao.find(bestEvent.getEventID()));
        assertEquals(authToken, aTDao.find(authToken.getAuthTokenID()));
        pause();
        ClearService clearService = new ClearService();
        clearService.clear();
        resume();
        assertNull(uDao.find(bestUser.getUserName()));
        assertNull(pDao.find(bestPerson.getPersonID()));
        assertNull(eDao.find(bestEvent.getEventID()));
        assertNull(aTDao.find(authToken.getAuthTokenID()));
    }

    @Test
    public void clearEmpty() throws DataAccessException {
        pause();
        ClearService clearService = new ClearService();
        clearService.clear();
        resume();
        assertNull(uDao.find(bestUser.getUserName()));
        assertNull(pDao.find(bestPerson.getPersonID()));
        assertNull(eDao.find(bestEvent.getEventID()));
        assertNull(aTDao.find(authToken.getAuthTokenID()));
    }

    //eventAllTests
    @Test
    public void eventAllPass() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(authToken);
        Event otherEvent = new Event("BigNeilsWedding", "BikeBoy", "cutegirl", 40.000,
                -98.000, "USA", "happyville", "marriage", 2021);
        eDao.insert(otherEvent);
        EventAllResult ear = new EventAllResult();
        ear.setData(new Event[]{bestEvent, otherEvent});
        ear.setSuccess(true);
        pause();
        EventAllService eventAllService = new EventAllService();
        assertEquals(eventAllService.eventAll(authToken.getAuthTokenID()), ear);
        resume();
    }

    @Test
    public void eventAllFail() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(new AuthToken("nothing", "someoneElse"));
        Event otherEvent = new Event("BigNeilsWedding", "BikeBoy", "cutegirl", 40.000,
                -98.000, "USA", "happyville", "marriage", 2021);
        eDao.insert(otherEvent);
        EventAllResult ear = new EventAllResult();
        pause();
        EventAllService eventAllService = new EventAllService();
        assertEquals(eventAllService.eventAll("nothing"), ear);
        resume();
    }

    //eventTests
    public EventRequest beforeEvent() {
        return new EventRequest("birthday", "abcd1234");
    }

    @Test
    public void eventPass() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(authToken);
        EventResult er = new EventResult();
        er.setAsEvent(bestEvent);
        er.setSuccess(true);
        pause();
        EventService eventService = new EventService();
        assertEquals(eventService.event(beforeEvent()), er);
        resume();
    }

    @Test
    public void eventFail() throws DataAccessException {
        uDao.insert(bestUser);
        aTDao.insert(authToken);
        EventResult er = new EventResult();
        er.setMessage("Error: no such event");
        er.setSuccess(false);
        pause();
        EventService eventService = new EventService();
        assertEquals(eventService.event(beforeEvent()), er);
        resume();
    }

    //fillTests
    @Test
    public void fillPass() throws DataAccessException {
        uDao.insert(bestUser);
        FillRequest r = new FillRequest("BikeBoy", 5);
        pause();
        FillService fillService = new FillService();
        FillResult fillResult = fillService.fill(r);
        resume();
        assertTrue(fillResult.isSuccess());
        assertEquals(fillResult.getMessage(), "Successfully added 63 persons and 187 events to the database.");
    }

    @Test
    public void fillInvalidUsername() throws DataAccessException {
        FillRequest r = new FillRequest("nobody", 5);
        pause();
        FillService fillService = new FillService();
        FillResult fillResult = fillService.fill(r);
        resume();
        assertFalse(fillResult.isSuccess());
        assertEquals(fillResult.getMessage(), "Error: Username not found");
    }
    //loadTests
    @Test
    public void loadPass() throws DataAccessException {
        LoadRequest r = new LoadRequest(new User[]{bestUser},
                new Person[]{bestPerson}, new Event[]{bestEvent});
        pause();
        LoadService loadService = new LoadService();
        LoadResult loadResult = loadService.load(r);
        resume();
        assertTrue(loadResult.isSuccess());
        assertEquals(loadResult.getMessage(), "Successfully added 1 users, 1 persons," +
                " and 1 events to the database.");
    }
    @Test
    public void loadEmpty() throws DataAccessException {
        LoadRequest r = new LoadRequest(new User[]{},
                new Person[]{}, new Event[]{});
        pause();
        LoadService loadService = new LoadService();
        LoadResult loadResult = loadService.load(r);
        resume();
        assertTrue(loadResult.isSuccess());
        assertEquals(loadResult.getMessage(), "Successfully added 0 users, 0 persons," +
                " and 0 events to the database.");
    }
    //loginTests
    @Test
    public void loginPass() throws DataAccessException {
        uDao.insert(bestUser);
        LoginRequest r = new LoginRequest(bestUser.getUserName(), bestUser.getPassword());
        pause();
        LoginService loginService = new LoginService();
        LoginResult loginResult = loginService.login(r);
        resume();
        assertEquals(loginResult.getUserName(), bestUser.getUserName());
        assertEquals(loginResult.getPersonID(), bestUser.getPersonID());
        assertNotNull(loginResult.getAuthToken());
        assertTrue(loginResult.isSuccess());
    }
    @Test
    public void loginWrongPassword() throws DataAccessException {
        uDao.insert(bestUser);
        LoginRequest r = new LoginRequest(bestUser.getUserName(), "password");
        pause();
        LoginService loginService = new LoginService();
        LoginResult loginResult = loginService.login(r);
        resume();
        assertFalse(loginResult.isSuccess());
        assertEquals(loginResult.getMessage(), "Error: Wrong Password");
    }

    //personAllTests
    @Test
    public void personAllPass() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(authToken);
        Person otherPerson = new Person("GrandpaMerlin", "BikeBoy", "Merlin",
                "Fish", "m", "MerlinK", "EvelynBang", "Pat");
        pDao.insert(otherPerson);
        PersonAllResult par = new PersonAllResult();
        par.setData(new Person[]{bestPerson, otherPerson});
        par.setSuccess(true);
        pause();
        PersonAllService personAllService = new PersonAllService();
        assertEquals(personAllService.personAll(authToken.getAuthTokenID()), par);
        resume();
    }

    @Test
    public void personAllFail() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(new AuthToken("nothing", "someoneElse"));
        Person otherPerson = new Person("GrandpaMerlin", "BikeBoy", "Merlin",
                "Fish", "m", "MerlinK", "EvelynBang", "Pat");
        pDao.insert(otherPerson);
        PersonAllResult par = new PersonAllResult();
        pause();
        PersonAllService personAllService = new PersonAllService();
        assertEquals(personAllService.personAll("nothing"), par);
        resume();
    }

    //personTests
    public PersonRequest beforePerson() {
        return new PersonRequest("GrandpaNeilDay", "abcd1234");
    }

    @Test
    public void personPass() throws DataAccessException {
        uDao.insert(bestUser);
        pDao.insert(bestPerson);
        eDao.insert(bestEvent);
        aTDao.insert(authToken);
        PersonResult pr = new PersonResult();
        pr.setAsPerson(bestPerson);
        pr.setSuccess(true);
        pause();
        PersonService personService = new PersonService();
        assertEquals(personService.person(beforePerson()), pr);
        resume();
    }

    @Test
    public void personFail() throws DataAccessException {
        uDao.insert(bestUser);
        aTDao.insert(authToken);
        PersonResult pr = new PersonResult();
        pr.setMessage("Error: no such person");
        pr.setSuccess(false);
        pause();
        PersonService personService = new PersonService();
        assertEquals(personService.person(beforePerson()), pr);
        resume();
    }

    //registerTests
    @Test
    public void registerPass() throws DataAccessException {
        RegisterResult rr = new RegisterResult();
        rr.setAuthToken("abcd1234");
        rr.setPersonID("lotsofbikes");
        rr.setUserName("");
        RegisterRequest r = new RegisterRequest("a", "b", "c",
                "d", "e", "f");
        pause();
        RegisterService registerService = new RegisterService();
        RegisterResult testResult = registerService.register(r);
        resume();
        assertEquals(testResult.getUserName(),"a");
        assertNotNull(testResult.getPersonID());
        assertNotNull(testResult.getAuthToken());
        assertEquals(pDao.findAll("a").length, 31);
    }

    @Test
    public void registerUsernameTaken() throws DataAccessException {
        RegisterResult rr = new RegisterResult();
        rr.setSuccess(false);
        rr.setMessage("Error: Username already exists");
        uDao.insert(bestUser);
        RegisterRequest r = new RegisterRequest("BikeBoy", "b", "c",
                "d", "e", "f");
        pause();
        RegisterService registerService = new RegisterService();
        RegisterResult testResult = registerService.register(r);
        resume();
        assertEquals(testResult.getMessage(), rr.getMessage());
        assertEquals(testResult.isSuccess(), rr.isSuccess());
    }
}
