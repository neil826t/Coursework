package Service;

import DAO.*;
import Model.Event;
import Model.Person;
import Model.User;
import Request.LoadRequest;
import Result.ClearResult;
import Result.LoadResult;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Clears all data from the database (just like the /clear API), and then loads the posted user, person, and event data into the database.
 */
public class LoadService {
    /**
     * Constructor
     */
    public LoadService() {}

    /**
     *
     * @param r a LoadRequest object
     * @return a LoadResult object
     */
    public LoadResult load (LoadRequest r) {

        LoadResult result = new LoadResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            db.clearTables();

            UserDao uDao = new UserDao(conn);
            PersonDao pDao = new PersonDao(conn);
            EventDao eDao = new EventDao(conn);

            for (User u : r.getUsers()) {
                uDao.insert(u);
            }
            for (Person p : r.getPersons()) {
                pDao.insert(p);
            }
            for (Event e : r.getEvents()) {
                eDao.insert(e);
            }

            result.setMessage("Successfully added " +
                    r.getUsers().length + " users, " +
                    r.getPersons().length + " persons, and " +
                    r.getEvents().length + " events to the database.");
            result.setSuccess(true);

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e) {

            result.setSuccess(false);
            result.setMessage("Error: DataAccessException");
        }

        return result;
    }
}
