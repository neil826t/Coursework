package Service;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.UserDao;
import Model.AuthToken;
import Model.User;
import Request.LoginRequest;
import Result.LoginResult;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

/**
 * Logs in the user and returns an auth token.
 */
public class LoginService {
    /**
     * Constructor
     */
    public LoginService() {}

    /**
     *
     * @param r a LoginRequest object
     * @return a LoginResult object
     */
    public LoginResult login (LoginRequest r) {

        LoginResult result = new LoginResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            UserDao uDao = new UserDao(conn);
            User newUser = uDao.find(r.getUserName());

            if (newUser == null) {
                result.setSuccess(false);
                result.setMessage("Error: No User Registered");
            } else if (!newUser.getPassword().equals(r.getPassword())) {
                result.setSuccess(false);
                result.setMessage("Error: Wrong Password");
            }

            else {
                AuthTokenDao aTDao = new AuthTokenDao(conn);
                String aT = UUID.randomUUID().toString();
                AuthToken authToken = new AuthToken(aT, r.getUserName());
                aTDao.insert(authToken);

                result.setAuthToken(aT);
                result.setPersonID(newUser.getPersonID());
                result.setUserName(newUser.getUserName());
                result.setSuccess(true);
            }
            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);
        }

        return result;
    }
}
