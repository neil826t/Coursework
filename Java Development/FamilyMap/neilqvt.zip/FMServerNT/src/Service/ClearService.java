package Service;

import DAO.DataAccessException;
import DAO.Database;
import Result.ClearResult;

/**
 * Deletes ALL data from the database, including user accounts, auth tokens, and generated person and event data.
 */
public class ClearService {
    /**
     * Constructor
     */
    public ClearService() {}

    /**
     * @return a ClearResult object
     */
    public ClearResult clear() {

        ClearResult clearResult = new ClearResult();
        Database db = new Database();

        try {
            db.getConnection();

            db.clearTables();
            clearResult.setSuccessMessage(true);

            db.closeConnection(true);
        } catch (DataAccessException e) {

            clearResult.setSuccessMessage(false);
        }

        return clearResult;
    }
}
