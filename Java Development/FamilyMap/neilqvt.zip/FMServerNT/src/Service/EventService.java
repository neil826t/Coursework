package Service;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.EventDao;
import Exceptions.WrongUsernameException;
import Model.Event;
import Request.EventRequest;
import Result.EventResult;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Returns the single Event object with the specified ID.
 */
public class EventService {
    /**
     * Constructor
     */
    public EventService() {}

    /**
     * @param r an EventRequest object
     * @return an EventResult object
     */
    public EventResult event(EventRequest r) {

        EventResult result = new EventResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            EventDao eDao = new EventDao(conn);
            Event event = eDao.find(r.getEventID());
            if (event == null) {
                throw new WrongUsernameException("no such event");
            }

            String aT = r.getAuthToken();
            AuthTokenDao aTDao = new AuthTokenDao(conn);
            if (!aTDao.find(aT).getUser().equals(event.getAssociatedUsername())) {
                throw new WrongUsernameException(aTDao.find(aT).getUser() + " vs " + event.getAssociatedUsername());
            }

            result.setAsEvent(event);
            result.setSuccess(true);

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);

        } catch (WrongUsernameException e) {
            result.setMessage("Error: " + e.getMessage());
            result.setSuccess(false);
        }

        return result;
    }
}
