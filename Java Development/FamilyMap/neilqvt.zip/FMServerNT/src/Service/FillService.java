package Service;

import DAO.DataAccessException;
import DAO.Database;
import DAO.UserDao;
import Model.User;
import Request.FillRequest;
import Result.FillResult;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Populates the server's database with generated data for the specified user name.
 * The required username parameter must be a user already registered with the server.
 * If there is any data in the database already associated with the given user name, it is deleted.
 * The optional generations parameter lets the caller specify the number of generations of ancestors to be generated,
 *  and must be a non-negative integer (the default is 4, which results in 31 new persons each with associated events).
 */
public class FillService extends GenerateAncestry{
    /**
     * Constructor
     */
    public FillService() {}
    /**
     *
     * @param r a FillRequest object
     * @return a FillResult object
     */
    public FillResult fill(FillRequest r) {

        FillResult result = new FillResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            UserDao uDao = new UserDao(conn);
            User user = uDao.find(r.getUsername());
            if (user == null) {
                result.setSuccess(false);
                result.setMessage("Error: Username not found");
            }

            else {
                uDao.clearTables(r.getUsername());
                generateAncestry(user, r.getGenerations(), conn);


                result.setMessage("Successfully added " +
                        getSize() + " persons and " +
                        getEventCount() + " events to the database.");
                result.setSuccess(true);
            }

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);

        } catch (FileNotFoundException e) {
            result.setMessage("Error: No name files for generation found");
            result.setSuccess(false);
        }

        return result;
    }
}
