package Service;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.PersonDao;
import Model.AuthToken;
import Model.Person;
import Result.PersonAllResult;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Returns ALL family members of the current user. The current user is determined from the provided auth token
 */
public class PersonAllService {
    /**
     * Constructor
     */
    public PersonAllService() {}

    /**
     * @return a PersonaAllResult object
     */
    public PersonAllResult personAll(String authToken) {

        PersonAllResult result = new PersonAllResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            AuthTokenDao aTDao = new AuthTokenDao(conn);
            AuthToken authToken1 = aTDao.find(authToken);

            PersonDao pDao = new PersonDao(conn);
            Person[] people = pDao.findAll(authToken1.getUser());

            result.setData(people);
            result.setSuccess(true);

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);
        }
        return result;
    }
}
