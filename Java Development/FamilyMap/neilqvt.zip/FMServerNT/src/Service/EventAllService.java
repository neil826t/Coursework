package Service;

import DAO.*;
import Model.AuthToken;
import Model.Event;
import Result.EventAllResult;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Returns ALL events for ALL family members of the current user. The current user is determined from the provided auth token.
 */
public class EventAllService {
    /**
     * Constructor
     */
    public EventAllService() {}

    /**
     * @return an EventAllResult object
     */
    public EventAllResult eventAll(String authToken) {

        EventAllResult result = new EventAllResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            AuthTokenDao aTDao = new AuthTokenDao(conn);
            AuthToken authToken1 = aTDao.find(authToken);

            EventDao eDao = new EventDao(conn);
            Event[] events = eDao.findAll(authToken1.getUser());

            result.setData(events);
            result.setSuccess(true);

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);
        }

        return result;
    }
}
