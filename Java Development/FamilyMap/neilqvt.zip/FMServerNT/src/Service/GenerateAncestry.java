package Service;

import DAO.DataAccessException;
import DAO.EventDao;
import DAO.PersonDao;
import Model.*;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

public abstract class GenerateAncestry {
    private User user;
    private Connection conn;
    private HashMap<Person, Integer> lastGen;
    private HashMap<Person, Integer> tempGen;

    private NamesList fnames;
    private LocationList locations;
    private NamesList mnames;
    private NamesList snames;

    private ArrayList<Person> allPeople;
    private int eventCount;

    protected void generateAncestry (User user, int generations, Connection conn) throws DataAccessException, FileNotFoundException {
        this.user = user;
        this.conn = conn;
        Random random = new Random();

        fnames = (new GsonBuilder().create()).fromJson(new BufferedReader(new FileReader("json/fnames.json")), NamesList.class);
        locations = (new GsonBuilder().create()).fromJson(new BufferedReader(new FileReader("json/locations.json")), LocationList.class);
        mnames = (new GsonBuilder().create()).fromJson(new BufferedReader(new FileReader("json/mnames.json")), NamesList.class);
        snames = (new GsonBuilder().create()).fromJson(new BufferedReader(new FileReader("json/snames.json")), NamesList.class);

        Person userPerson = new Person(
                user.getPersonID(),
                user.getUserName(),
                user.getFirstName(),
                user.getLastName(),
                user.getGender(),
                null, null, null
        );
        PersonDao pDao = new PersonDao(conn);
        allPeople = new ArrayList<>();
        allPeople.add(userPerson);

        //User random birth event
        Location birthLocation = locations.getData()[random.nextInt(locations.getData().length)];
        Event userBirth = new Event(
                UUID.randomUUID().toString(), //Event ID
                user.getUserName(),
                user.getPersonID(),
                birthLocation.getLatitude(),
                birthLocation.getLongitude(),
                birthLocation.getCountry(),
                birthLocation.getCity(),
                "birth",
                1999
                );
        EventDao eDao = new EventDao(conn);
        eDao.insert(userBirth);
        eventCount = 1;


        lastGen = new HashMap<>();
        tempGen = new HashMap<>();
        makeParents(userPerson, 1999);
        for (Person person : tempGen.keySet()) {
            lastGen.put(person, tempGen.get(person));
        }
        tempGen.clear();

        for (int i = 1; i < generations; i++) {
            for (Person person : lastGen.keySet()) {
                makeParents(person, lastGen.get(person));
            }
            lastGen.clear();
            for (Person person : tempGen.keySet()) {
                lastGen.put(person, tempGen.get(person));
            }
            tempGen.clear();
        }

        for (Person p : allPeople) {
            pDao.insert(p);
        }
    }

    private void makeParents(Person child, int birthYear) throws DataAccessException {
        Random random = new Random();

        int mothersAge = 17 + random.nextInt(33);
        int fathersAge = 17 + random.nextInt(45);
        int mothersBirthYear = birthYear - mothersAge;
        int fathersBirthYear = birthYear - fathersAge;
        int youngerYear = mothersBirthYear;
        if (fathersBirthYear > mothersBirthYear) {
            youngerYear = fathersBirthYear;
        }
        int marriageYear = youngerYear + 17 + random.nextInt(birthYear - youngerYear - 16);

        Location marriagePlace = locations.getData()[random.nextInt(locations.getData().length)];

        String dadID = UUID.randomUUID().toString();
        String momID = UUID.randomUUID().toString();

        child.setFatherID(dadID);
        child.setMotherID(momID);

        Person dad = new Person(
                dadID,
                user.getUserName(),
                mnames.getData()[random.nextInt(mnames.getData().length)],
                child.getLastName(),
                "m",
                null, null, momID
        );
        allPeople.add(dad);
        makeEvents(dadID, fathersBirthYear, marriageYear, marriagePlace, birthYear);


        Person mom = new Person(
                momID,
                user.getUserName(),
                fnames.getData()[random.nextInt(fnames.getData().length)],
                snames.getData()[random.nextInt(snames.getData().length)],
                "f",
                null, null, dadID
        );
        allPeople.add(mom);
        makeEvents(momID, mothersBirthYear, marriageYear, marriagePlace, birthYear);


        tempGen.put(dad, fathersBirthYear);
        tempGen.put(mom, mothersBirthYear);
    }

    private void makeEvents(String personID, int birthYear, int marriage,
                            Location marriageLocation, int childYear) throws DataAccessException {

        Random random = new Random();

        Location birthLocation = locations.getData()[random.nextInt(locations.getData().length)];
        Event birthEvent = new Event(
                UUID.randomUUID().toString(), //Event ID
                user.getUserName(),
                personID,
                birthLocation.getLatitude(),
                birthLocation.getLongitude(),
                birthLocation.getCountry(),
                birthLocation.getCity(),
                "birth",
                birthYear
        );

        Event marriageEvent = new Event(
                UUID.randomUUID().toString(), //Event ID
                user.getUserName(),
                personID,
                marriageLocation.getLatitude(),
                marriageLocation.getLongitude(),
                marriageLocation.getCountry(),
                marriageLocation.getCity(),
                "marriage",
                marriage
        );

        Location deathLocation = locations.getData()[random.nextInt(locations.getData().length)];
        int deathYear = childYear + random.nextInt(birthYear + 120 - childYear);
        Event deathEvent = new Event(
                UUID.randomUUID().toString(), //Event ID
                user.getUserName(),
                personID,
                deathLocation.getLatitude(),
                deathLocation.getLongitude(),
                deathLocation.getCountry(),
                deathLocation.getCity(),
                "death",
                deathYear
        );

        EventDao eDao = new EventDao(conn);
        eDao.insert(birthEvent);
        eDao.insert(marriageEvent);
        eDao.insert(deathEvent);

        eventCount += 3;
    }

    protected int getSize() {
        if (allPeople == null) {
            return 0;
        }
        return allPeople.size();
    }

    protected int getEventCount() {
        return eventCount;
    }
}
