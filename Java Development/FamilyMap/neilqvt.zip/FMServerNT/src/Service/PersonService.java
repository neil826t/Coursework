package Service;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.PersonDao;
import Exceptions.WrongUsernameException;
import Model.Person;
import Request.PersonRequest;
import Result.PersonResult;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Returns the single Person object with the specified ID.
 */
public class PersonService {
    /**
     * Constructor
     */
    public PersonService() {}

    /**
     * @param r a PersonRequest object
     * @return a PersonResult object
     */
    public PersonResult person(PersonRequest r) {

        PersonResult result = new PersonResult();
        Database db = new Database();

        try (Connection conn = db.getConnection()) {

            PersonDao pDao = new PersonDao(conn);
            Person person = pDao.find(r.getPersonID());
            if (person == null) {
                throw new WrongUsernameException("no such person");
            }

            String aT = r.getAuthToken();
            AuthTokenDao aTDao = new AuthTokenDao(conn);
            if (!aTDao.find(aT).getUser().equals(person.getAssociatedUsername())) {
                throw new WrongUsernameException();
            }

            result.setAsPerson(person);
            result.setSuccess(true);

            db.closeConnection(true);
        } catch (DataAccessException | SQLException e ) {

            result.setMessage(e.getMessage());
            result.setSuccess(false);

        } catch (WrongUsernameException e) {
            result.setMessage("Error: Requested person does not belong to this user");
            result.setSuccess(false);
        }

        return result;
    }

}
