package Handlers;

import Result.PersonAllResult;
import Service.PersonAllService;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

public class PersonAllRequestHandler extends AuthorizingRequestHandler{
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        PersonAllResult result = new PersonAllResult();

        if (exchange.getRequestMethod().toUpperCase().equals("GET")) {

            if (authorize(exchange.getRequestHeaders())) {
                String authToken = exchange.getRequestHeaders().getFirst("Authorization");
                PersonAllService service = new PersonAllService();
                result = service.personAll(authToken);

            } else {
                unAuthorize(result);
            }

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
