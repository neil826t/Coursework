package Handlers;

import Request.EventRequest;
import Result.EventResult;
import Result.PersonResult;
import Service.EventService;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

public class EventRequestHandler extends AuthorizingRequestHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        EventResult result = new EventResult();

        if (exchange.getRequestMethod().toUpperCase().equals("GET")) {

            String EventID = exchange.getRequestURI().toString().substring(7);

            if (authorize(exchange.getRequestHeaders())) {
                String authToken = exchange.getRequestHeaders().getFirst("Authorization");
                EventRequest request = new EventRequest(EventID, authToken);
                EventService service = new EventService();
                result = service.event(request);

            } else {
                unAuthorize(result);
            }

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
