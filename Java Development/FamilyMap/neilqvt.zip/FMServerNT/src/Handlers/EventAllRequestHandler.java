package Handlers;

import Result.EventAllResult;
import Result.PersonResult;
import Service.EventAllService;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.HttpURLConnection;

public class EventAllRequestHandler extends AuthorizingRequestHandler{
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        EventAllResult result = new EventAllResult();

        if (exchange.getRequestMethod().toUpperCase().equals("GET")) {

            if (authorize(exchange.getRequestHeaders())) {
                String authToken = exchange.getRequestHeaders().getFirst("Authorization");
                EventAllService service = new EventAllService();
                result = service.eventAll(authToken);

            } else {
                unAuthorize(result);
            }

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
