package Handlers;

import Request.LoadRequest;
import Result.LoadResult;
import Result.RegisterResult;
import Service.LoadService;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.InputStream;

public class LoadRequestHandler extends PostRequestHandler {
    /**
     * It's gonna pass in a
     * @param exchange
     * @throws IOException
     */
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        LoadResult result = new LoadResult();

        if (exchange.getRequestMethod().toUpperCase().equals("POST")) {

            InputStream reqBody = exchange.getRequestBody();
            String reqData = readString(reqBody);

            //parse reqData into 3 groups
            LoadRequest request = deserialize(reqData, LoadRequest.class);
            LoadService service = new LoadService();
            result = service.load(request);

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
