package Handlers;

import Result.Result;
import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;

public abstract class RequestHandler implements HttpHandler {

    protected static <T> T deserialize(String value, Class<T> returnType) {
        return (new Gson()).fromJson(value, returnType);
    }


    protected void sendResponse(Result result, HttpExchange exchange) throws IOException {
        if (result.isSuccess()) {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
        } else {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
        }

        OutputStream respBody = exchange.getResponseBody();
        writeString(result.body(), respBody);
        respBody.close();
    }


    protected void requestPropertyError(Result result) throws IOException {
        result.setSuccess(false);
        result.setMessage("Request property missing or has invalid value error");
    }


    private void writeString(String str, OutputStream os) throws IOException {
        OutputStreamWriter sw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(sw);
        bw.write(str);
        bw.flush();
    }
}
