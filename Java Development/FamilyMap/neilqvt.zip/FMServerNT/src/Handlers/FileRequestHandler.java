package Handlers;

import com.sun.net.httpserver.HttpExchange;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.nio.file.Files;

public class FileRequestHandler extends RequestHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        String urlPath = exchange.getRequestURI().toString();
        if (urlPath.equals("/") || urlPath.equals(null)) {
            urlPath = "/index.html";
        }
        String filePath = "web" + urlPath;
        File newFile = new File(filePath);

        if (!newFile.exists()) {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_NOT_FOUND, 0);
            filePath = "web/404.html";
            newFile = new File(filePath);

        } else {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
        }

        OutputStream respBody = exchange.getResponseBody();
        System.out.println(filePath);
        Files.copy(newFile.toPath(), respBody);
        respBody.close();
    }
}
