package Handlers;

import Result.ClearResult;
import Service.ClearService;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

public class ClearRequestHandler extends PostRequestHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        ClearResult result = new ClearResult();

        if (exchange.getRequestMethod().toUpperCase().equals("POST")) {

            ClearService clearService = new ClearService();
            result = clearService.clear();

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
