package Handlers;

import Request.FillRequest;
import Result.FillResult;
import Service.FillService;
import Service.RegisterService;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

public class FillRequestHandler extends PostRequestHandler{
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        FillResult result = new FillResult();

        if (exchange.getRequestMethod().toUpperCase().equals("POST")) {

            String userName = exchange.getRequestURI().toString().substring(6);
            String generations = null;
            if (userName.contains("/")) {
                generations = userName.split("/")[1];
                userName = userName.split("/")[0];
            }
            if (generations == null) {
                generations = "4";
            }
            int gens = Integer.parseInt(generations);

            FillRequest request = new FillRequest(userName, gens);
            FillService service = new FillService();
            result = service.fill(request);

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }

}
