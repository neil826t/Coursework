package Handlers;

import Request.LoginRequest;
import Result.LoginResult;
import Result.RegisterResult;
import Service.LoginService;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.InputStream;

public class LoginRequestHandler extends PostRequestHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        LoginResult result = new LoginResult();

        if (exchange.getRequestMethod().toUpperCase().equals("POST")) {

            InputStream reqBody = exchange.getRequestBody();
            String reqData = readString(reqBody);

            LoginRequest request = deserialize(reqData, LoginRequest.class);
            LoginService service = new LoginService();
            result = service.login(request);

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
