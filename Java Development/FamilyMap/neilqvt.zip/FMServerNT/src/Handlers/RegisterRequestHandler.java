package Handlers;

import Request.RegisterRequest;
import Result.RegisterResult;
import Service.RegisterService;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.io.InputStream;

public class RegisterRequestHandler extends PostRequestHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        RegisterResult result = new RegisterResult();

        if (exchange.getRequestMethod().toUpperCase().equals("POST")) {
            InputStream reqBody = exchange.getRequestBody();
            String reqData = readString(reqBody);

            RegisterRequest request = deserialize(reqData, RegisterRequest.class);
            RegisterService service = new RegisterService();
            result = service.register(request);

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
