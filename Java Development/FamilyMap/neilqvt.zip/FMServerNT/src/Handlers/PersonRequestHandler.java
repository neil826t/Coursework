package Handlers;

import Request.PersonRequest;
import Result.PersonResult;
import Service.PersonService;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;

public class PersonRequestHandler extends AuthorizingRequestHandler{
    @Override
    public void handle(HttpExchange exchange) throws IOException {

        PersonResult result = new PersonResult();

        if (exchange.getRequestMethod().toUpperCase().equals("GET")) {

            String personID = exchange.getRequestURI().toString().substring(8);

            if (authorize(exchange.getRequestHeaders())) {
                String authToken = exchange.getRequestHeaders().getFirst("Authorization");
                PersonRequest request = new PersonRequest(personID, authToken);
                PersonService service = new PersonService();
                result = service.person(request);

            } else {
                unAuthorize(result);
            }

        } else {
            requestPropertyError(result);
        }

        sendResponse(result, exchange);
    }
}
