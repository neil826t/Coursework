package Handlers;

import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import Result.Result;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.sql.Connection;
import java.sql.SQLException;

public abstract class AuthorizingRequestHandler extends RequestHandler {
    protected boolean authorize(Headers headers) {

        if (headers.containsKey("Authorization")) {
            String authToken = headers.getFirst("Authorization");
            Database db = new Database();

            try (Connection conn = db.getConnection()) {
                AuthTokenDao aTDao = new AuthTokenDao(conn);
                if (aTDao.find(authToken) == null) {
                    return false;
                }

                db.closeConnection(true);
            } catch (DataAccessException | SQLException e) {
                return false;
            }

            return true;
        }

        return false;
    }
    protected void unAuthorize(Result result) throws IOException {
        result.setSuccess(false);
        result.setMessage("Unauthorized token error");
    }
}
