package Model;

import java.util.Objects;

/**
 * Authorization Token for each login
 */
public class AuthToken {
    /**
     * Auth Token
     */
    private String authTokenID;

    /**
     * Associated User
     */
    private String user;

    public AuthToken(String authTokenID, String user) {
        this.authTokenID = authTokenID;
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthToken authToken = (AuthToken) o;
        return Objects.equals(authTokenID, authToken.authTokenID) &&
                Objects.equals(user, authToken.user);
    }

    /**
     * Constructor
     */


    public String getAuthTokenID() {
        return authTokenID;
    }

    public void setAuthTokenID(String authTokenID) {
        this.authTokenID = authTokenID;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
