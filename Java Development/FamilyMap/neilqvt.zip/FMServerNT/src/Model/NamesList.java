package Model;

public class NamesList {
    private String[] data;

    public String[] getData() {
        return data;
    }

    public NamesList(String[] data) {
        this.data = data;
    }
}
