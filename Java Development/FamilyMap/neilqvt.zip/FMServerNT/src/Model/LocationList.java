package Model;

public class LocationList {
    private Location[] data;

    public LocationList(Location[] data) {
        this.data = data;
    }

    public Location[] getData() {
        return data;
    }
}
