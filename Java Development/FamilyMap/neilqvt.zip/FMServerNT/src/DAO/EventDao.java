package DAO;

import Model.Event;
import Model.Person;
import Model.User;

import java.sql.*;
import java.util.ArrayList;

/**
 * Access database dealing with Event data
 */
public class EventDao {
    private final Connection conn;

    public EventDao(Connection conn) { this.conn = conn; }

    /**
     * Inserts an event into the database
     * @param event
     */
    public void insert(Event event) throws DataAccessException {
        //We can structure our string to be similar to a sql command, but if we insert question
        //marks we can change them later with help from the statement
        String sql = "INSERT INTO Event (id, user, person_id, latitude, longitude, " +
                "country, city, event_type, year) VALUES(?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            //Using the statements built-in set(type) functions we can pick the question mark we want
            //to fill in and give it a proper value. The first argument corresponds to the first
            //question mark found in our sql String
            stmt.setString(1, event.getEventID());
            stmt.setString(2, event.getAssociatedUsername());
            stmt.setString(3, event.getPersonID());
            stmt.setDouble(4, event.getLatitude());
            stmt.setDouble(5, event.getLongitude());
            stmt.setString(6, event.getCountry());
            stmt.setString(7, event.getCity());
            stmt.setString(8, event.getEventType());
            stmt.setInt(9, event.getYear());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Error encountered while inserting into the database");
        }
    }

    /**
     * Clears everything from the table
     */
    public void clearTables() throws DataAccessException
    {

        try (Statement stmt = conn.createStatement()){
            String sql = "DELETE FROM Event";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            throw new DataAccessException("SQL Error encountered while clearing tables");
        }
    }


    /**
     * accesses an event by its ID from the database
     * @param eventID a String representing the event ID
     * @return the associated event
     */
    public Event find(String eventID) throws DataAccessException {
        Event event;
        ResultSet rs = null;

        String sql = "SELECT * FROM Event WHERE id = ?;";

        try(PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, eventID);
            rs = stmt.executeQuery();

            if(rs.next()) {
                event = new Event(rs.getString("id"), rs.getString("user"),
                        rs.getString("person_id"), rs.getDouble("latitude"),
                        rs.getDouble("longitude"), rs.getString("country"),
                        rs.getString("city"), rs.getString("event_type"),
                        rs.getInt("year"));
                return event;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding event");

        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public Event[] findAll(String userName) throws DataAccessException {
        ArrayList<Event> eventsAL = new ArrayList<Event>();
        ResultSet rs = null;

        String sql = "SELECT * FROM Event WHERE user = ?;";

        try(PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userName);
            rs = stmt.executeQuery();

            while(rs.next()) {
                eventsAL.add(new Event(rs.getString("id"), rs.getString("user"),
                        rs.getString("person_id"), rs.getDouble("latitude"),
                        rs.getDouble("longitude"), rs.getString("country"),
                        rs.getString("city"), rs.getString("event_type"),
                        rs.getInt("year")));
            }

            if (eventsAL.size() > 0) {
                return eventsAL.toArray(new Event[0]);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding events");

        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}
