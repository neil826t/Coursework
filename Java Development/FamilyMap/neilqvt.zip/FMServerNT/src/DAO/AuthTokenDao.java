package DAO;

import Model.AuthToken;
import Model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Access database dealing with AuthToken data
 */
public class AuthTokenDao {
    private final Connection conn;

    public AuthTokenDao(Connection conn) { this.conn = conn; }
    
    /**
     * Inserts an authToken into the database
     * @param authToken
     */
    public void insert(AuthToken authToken) throws DataAccessException {
        String sql = "INSERT INTO AuthToken (id, user) VALUES(?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, authToken.getAuthTokenID());
            stmt.setString(2, authToken.getUser());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Error encountered while inserting into the database");
        }
    }

    /**
     * accesses an authToken by its ID from the database
     * @param authToken the authToken as a string
     * @return the associated authToken
     */
    public AuthToken find(String authToken) throws DataAccessException {
        AuthToken authToken1;

        ResultSet rs = null;
        String sql = "SELECT * FROM AuthToken WHERE id = ?;";

        try(PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, authToken);
            rs = stmt.executeQuery();
            if(rs.next()) {
                authToken1 = new AuthToken(rs.getString("id"), rs.getString("user"));
                return authToken1;
            }

        } catch (SQLException e) {
            throw new DataAccessException("Error encountered while finding user");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}
