package Result;

import Model.Event;
import Model.Person;

import java.util.Objects;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body returns an associatedUsername, an eventID, a personID, a latitude and longitude, a country, city, eventType, and year, along with success as true
 * Errors: Invalid auth token, Invalid eventID parameter, Requested event does not belong to this user, Internal server error
 */
public class EventResult extends Result{
    /**
     * Username of user account this event belongs to (non-empty string)
     */
    private String associatedUsername;

    /**
     * Event’s unique ID (non-empty string)
     */
    private String eventID;

    /**
     * ID of the person this event belongs to (non-empty string)
     */
    private String personID;

    /**
     * Latitude of the event’s location (number)
     */
    private double latitude;

    /**
     * Longitude of the event’s location (number)
     */
    private double longitude;

    /**
     * Name of country where event occurred (non-empty string)
     */
    private String country;

    /**
     * Name of city where event occurred (non-empty string)
     */
    private String city;

    /**
     * Type of event (birth, baptism, etc.) (non-empty string)
     */
    private String eventType;

    /**
     * Year the event occurred (integer)
     */
    private int year;

    /**
     * Constructor
     */
    public EventResult() {}

    @Override
    public String body() {
        if (success) {
            return "{ " +
                    "\n\t\"associatedUsername\":\"" + associatedUsername + "\"," +
                    "\n\t\"eventID\":\"" + eventID + "\"," +
                    "\n\t\"personID\":\"" + personID + "\"," +
                    "\n\t\"latitude\":\"" + latitude + "\"," +
                    "\n\t\"longitude\":\"" + longitude + "\"," +
                    "\n\t\"country\":\"" + country + "\"," +
                    "\n\t\"city\":\"" + city + "\"," +
                    "\n\t\"eventType\":\"" + eventType + "\"," +
                    "\n\t\"year\":\"" + year + "\"," +
                    "\n\t\"success\":\"" + true + "\"" +
                    "\n}";
        }
        return "{ " +
                "\n\t\"message\":\"" + message + "\"," +
                "\n\t\"success\":\"" + false + "\"" +
                "\n}";
    }

    public void setAsEvent(Event event) {
        setAssociatedUsername(event.getAssociatedUsername());
        setPersonID(event.getPersonID());
        setEventID(event.getEventID());
        setLatitude(event.getLatitude());
        setLongitude(event.getLongitude());
        setCountry(event.getCountry());
        setCity(event.getCity());
        setEventType(event.getEventType());
        setYear(event.getYear());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventResult that = (EventResult) o;

        return Double.compare(that.latitude, latitude) == 0 &&
                Double.compare(that.longitude, longitude) == 0 &&
                year == that.year &&
                Objects.equals(associatedUsername, that.associatedUsername) &&
                Objects.equals(eventID, that.eventID) &&
                Objects.equals(personID, that.personID) &&
                Objects.equals(country, that.country) &&
                Objects.equals(city, that.city) &&
                Objects.equals(eventType, that.eventType);
    }

    public String getAssociatedUsername() {
        return associatedUsername;
    }

    public void setAssociatedUsername(String associatedUsername) {
        this.associatedUsername = associatedUsername;
    }

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
