package Result;

/**
 * A base class for all Result classes
 * Has variables message and success
 * Error Response Body shows a message with a description of the error and a false success
 */
public class Result {
    /**
     * Constructor
     */
    public Result() {}

    /**
     * Description of the error
     */
    String message;
    /**
     * whether or not the Result is successful
     */
    boolean success;

    public String body() {
        return "{" +
                "\n    \"message\":\"" + message + "\"," +
                "\n    \"success\":\"" + success + "\"" +
                "\n}";
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
