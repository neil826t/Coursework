package Result;
import Model.Event;
import Model.Person;

import java.util.Arrays;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body: The response body returns a JSON object with a data attribute that contains an array of Event objects.  Each Event object has the same format as described in previous section on the /event/[eventID] API.
 * Errors: Invalid auth token, Internal server error
 */
public class EventAllResult extends Result{
    /**
     * Array of Event objects
     */
    public Event[] data;

    /**
     * Constructor
     */
    public EventAllResult() {}

    @Override
    public String body() {
        if (success) {

            String eventJson = "";
            for (Event e : data) {
                eventJson += e.toJson();
                eventJson += ",\n";
            }

            eventJson = eventJson.substring(0, eventJson.length() - 2);

            return "{ " +
                    "\n\t\"data\": [\n" +
                    eventJson +
                    "\n]," +
                    "\n\t\"success\":\"" + true + "\"" +
                    "\n}";
        }
        return "{ " +
                "\n\t\"message\":\"" + message + "\"," +
                "\n\t\"success\":\"" + false + "\"" +
                "\n}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EventAllResult that = (EventAllResult) o;
        return Arrays.equals(data, that.data);
    }


    public void setData(Event[] data) {
        this.data = data;
    }
}
