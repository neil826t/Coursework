package Result;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body returns \"Successfully added X users, Y persons, and Z events to the database.\" as message and success as true
 * Errors: Invalid request data (missing values, invalid values, etc.), Internal server error
 */
public class LoadResult extends Result{
    /**
     * Constructor
     */
    public LoadResult() {}
}
