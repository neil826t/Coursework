package Result;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body gives authToken, userName, personID, and success as true
 * Errors: Request property missing or has invalid value, Username already taken by another user, Internal server error
 */
public class RegisterResult extends Result {
    private String authToken;
    private String userName;
    private String personID;

    /**
     * Constructor
     */
    public RegisterResult() {}

    @Override
    public String body() {
        if (success) {
            return "{ " +
                    "\n\t\"authToken\":\"" + authToken + "\"," +
                    "\n\t\"userName\":\"" + userName + "\"," +
                    "\n\t\"personID\":\"" + personID + "\"," +
                    "\n\t\"success\":\"" + true + "\"" +
                    "\n}";
        }
        return "{ " +
                "\n\t\"message\":\"" + message + "\"," +
                "\n\t\"success\":\"" + false + "\"" +
                "\n}";
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }
}
