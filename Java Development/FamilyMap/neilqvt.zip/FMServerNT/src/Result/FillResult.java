package Result;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body returns -Successfully added X persons and Y events to the database- as message and success as true
 * Errors: Invalid username or generations parameter, Internal server error
 */
public class FillResult extends Result{
    /**
     * Constructor
     */
    public FillResult() {}
}
