package Result;
import Model.Person;

import java.util.Arrays;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body: The response body returns a JSON object with a data attribute that contains an array of Person objects.  Each Person object has the same format as described in previous section on the /person/[personID] API.
 * Errors: Invalid auth token, Internal server error
 */
public class PersonAllResult extends Result{
    /**
     * Array of Person objects
     */
    private Person[] data;
    /**
     * Constructor
     */
    public PersonAllResult() {}

    @Override
    public String body() {
        if (success) {

            String peopleJson = "";
            for (Person p : data) {
                peopleJson += p.toJson();
                peopleJson += ",\n";
            }
            peopleJson = peopleJson.substring(0, peopleJson.length() - 2);

            return "{ " +
                    "\n\t\"data\": [\n" +
                    peopleJson +
                    "\n]," +
                    "\n\t\"success\":\"" + true + "\"" +
                    "\n}";
        }

        return "{ " +
                "\n\t\"message\":\"" + message + "\"," +
                "\n\t\"success\":\"" + false + "\"" +
                "\n}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonAllResult that = (PersonAllResult) o;
        return Arrays.equals(data, that.data);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(data);
    }

    public Person[] getData() {
        return data;
    }

    public void setData(Person[] data) {
        this.data = data;
    }
}
