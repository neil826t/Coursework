package Result;

/**
 * A Response Body that either responds with a success or an error
 * Success Response Body returns "Clear succeeded" message and success as true
 * Errors: Internal server error
 */
public class ClearResult extends Result {
    /**
     * Constructor
     */
    public ClearResult() {}

    public void setSuccessMessage(boolean success) {
        setSuccess(success);
        if (success) {
            setMessage("Clear succeeded.");
        } else {
            setMessage("DataAccessException");
        }
    }
}
