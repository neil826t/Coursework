package DAOTests;

import DAO.DataAccessException;
import DAO.Database;
import DAO.EventDao;
import Model.Event;
import Model.Person;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;

import static org.junit.jupiter.api.Assertions.*;

public class EventDAOTest {
    private Database db;
    private Event bestEvent;
    private Event otherEvent;
    private EventDao eDao;

    @BeforeEach
    public void setUp() throws DataAccessException
    {
        db = new Database();
        bestEvent = new Event("birthday", "BikeBoy", "biking", 40.000,
            -86.000, "USA", "Indiana-town", "birth", 1999);
        otherEvent = new Event("BigNeilsWedding", "BikeBoy", "cutegirl", 40.000,
                -98.000, "USA", "happyville", "marriage", 2021);
        Connection conn = db.getConnection();
        db.clearTables();
        eDao = new EventDao(conn);
    }

    @AfterEach
    public void tearDown() throws DataAccessException {
        db.closeConnection(false);
    }

    /**
     * Hit two birds with one stone - positive tests for both insert and find
     * @throws DataAccessException
     */
    @Test
    public void insertAndRetrievalPass() throws DataAccessException {
        eDao.insert(bestEvent);
        Event compareTest = eDao.find(bestEvent.getEventID());
        assertNotNull(compareTest);
        assertEquals(bestEvent, compareTest);
    }

    /**
     * Negative test for insert
     * @throws DataAccessException
     */
    @Test
    public void insertFail() throws DataAccessException {
        eDao.insert(bestEvent);
        assertThrows(DataAccessException.class, ()-> eDao.insert(bestEvent));
    }

    /**
     * Negative test for find
     * @throws DataAccessException
     */
    @Test
    public void retrievalFail() throws DataAccessException {
        assertNull(eDao.find("Well Hello"));
    }

    /**
     * Primary test for clear
     * @throws DataAccessException
     */
    @Test
    public void clearPass() throws DataAccessException {
        eDao.insert(bestEvent);
        assertEquals(bestEvent, eDao.find(bestEvent.getEventID()));
        eDao.clearTables();
        assertNull(eDao.find(bestEvent.getPersonID()));
    }

    /**
     * secondary test for clear
     * @throws DataAccessException
     */
    @Test
    public void clearEmpty() throws DataAccessException {
        eDao.clearTables();
        assertNull(eDao.find(bestEvent.getEventID()));
    }

    /**
     * Positive test for findAll
     */
    @Test
    public void findAllPass() throws DataAccessException {
        eDao.insert(bestEvent);
        eDao.insert(otherEvent);
        Event compareTest1 = eDao.find(bestEvent.getEventID());
        Event compareTest2 = eDao.find(otherEvent.getEventID());
        assertNotNull(compareTest1);
        assertNotNull(compareTest2);
        assertEquals(bestEvent, compareTest1);
        assertEquals(otherEvent, compareTest2);
        Event[] events = eDao.findAll(bestEvent.getAssociatedUsername());
        assertEquals(events[0], compareTest1);
        assertEquals(events[1], compareTest2);
    }

    /**
     * Negative test for findAll
     */
    @Test
    public void findAllFail() throws DataAccessException {
        eDao.insert(bestEvent);
        eDao.insert(otherEvent);
        Event compareTest1 = eDao.find(bestEvent.getEventID());
        Event compareTest2 = eDao.find(otherEvent.getEventID());
        assertNotNull(compareTest1);
        assertNotNull(compareTest2);
        assertEquals(bestEvent, compareTest1);
        assertEquals(otherEvent, compareTest2);
        Event[] events = eDao.findAll("Neils wife");
        assertNull(events);
    }
}
