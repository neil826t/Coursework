package DAOTests;
import DAO.AuthTokenDao;
import DAO.DataAccessException;
import DAO.Database;
import DAO.PersonDao;
import Model.AuthToken;
import Model.Person;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Connection;

import static org.junit.jupiter.api.Assertions.*;
public class AuthTokenDAOTest {
    private Database db;
    private AuthToken authToken;
    private AuthTokenDao aTDao;

    @BeforeEach
    public void setUp() throws DataAccessException
    {
        db = new Database();
        authToken = new AuthToken("abcd1234", "duckyninjamath");
        Connection conn = db.getConnection();
        db.clearTables();
        aTDao = new AuthTokenDao(conn);
    }

    @AfterEach
    public void tearDown() throws DataAccessException {
        db.closeConnection(false);
    }

    /**
     * Hit two birds with one stone - positive tests for both insert and find
     * @throws DataAccessException
     */
    @Test
    public void insertAndRetrievalPass() throws DataAccessException {
        aTDao.insert(authToken);
        AuthToken compareTest = aTDao.find(authToken.getAuthTokenID());
        assertNotNull(compareTest);
        assertEquals(authToken, compareTest);
    }

    /**
     * Negative test for insert
     * @throws DataAccessException
     */
    @Test
    public void insertFail() throws DataAccessException {
        aTDao.insert(authToken);
        assertThrows(DataAccessException.class, ()-> aTDao.insert(authToken));
    }

    /**
     * Negative test for find
     * @throws DataAccessException
     */
    @Test
    public void retrievalFail() throws DataAccessException {
        assertNull(aTDao.find("Well Hello"));
    }
}
